const fetchGithubInfo = (name, callback) => {
  fetch('https://api.github.com/repos/' + name)
  .then(response => response.json())
  .then(data => callback(data));
}

module.exports = fetchGithubInfo;