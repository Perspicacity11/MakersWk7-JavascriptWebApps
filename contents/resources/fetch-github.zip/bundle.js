(() => {
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[Object.keys(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // fetchGithubInfo.js
  var require_fetchGithubInfo = __commonJS({
    "fetchGithubInfo.js"(exports, module) {
      var fetchGithubInfo2 = (name, callback) => {
        fetch("https://api.github.com/repos/" + name).then((response) => response.json()).then((data) => callback(data));
      };
      module.exports = fetchGithubInfo2;
    }
  });

  // updateView.js
  var require_updateView = __commonJS({
    "updateView.js"(exports, module) {
      var updateView2 = (repoData) => {
        document.querySelector("#repo-name").innerText = repoData.full_name;
        document.querySelector("#repo-image").src = repoData.organization.avatar_url;
        document.querySelector("#repo-description").innerText = repoData.description;
        document.querySelector("#repo-link").setAttribute("href", repoData.html_url);
        document.querySelector("#repo-language").innerText = repoData.language;
      };
      module.exports = updateView2;
    }
  });

  // index.js
  var fetchGithubInfo = require_fetchGithubInfo();
  var updateView = require_updateView();
  var inputEl = document.querySelector("#repo-name-input");
  var buttonEl = document.querySelector("#repo-submit");
  buttonEl.addEventListener("click", () => {
    let name = inputEl.value;
    fetchGithubInfo(name, (data) => {
      updateView(data);
    });
  });
})();
