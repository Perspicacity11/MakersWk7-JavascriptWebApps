const View = require("./view");

const view = new View();