const MessageView = require("./messageView");

const view = new MessageView();