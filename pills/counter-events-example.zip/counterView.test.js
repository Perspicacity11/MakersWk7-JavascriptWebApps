/**
 * @jest-environment jsdom
 */

// file: titleView.test.js

const fs = require('fs');
const CounterView = require('./counterView');

describe('Counter view', () => {

  it('displays initial value of 0', () => {
    // 1. Arrange - load the HTML so Jest can build its own DOM tree 
    // and instantiate our View class
    document.body.innerHTML = fs.readFileSync('./index.html');    
    const view = new CounterView();

    // 2. Act - already done!
    // (instantiating the CounterView displays the initial value of 0)

    // 3. Assert - using querySelector,
    // we get the DOM element and assert its content (should be '0')
    const counterEl = document.querySelector('#counter');
    expect(counterEl.innerText).toBe('0')
  });

  it('increments the value to 1', () => {
    // 1. Arrange - load the HTML so Jest can build its own DOM tree 
    // and instantiate our View class
    document.body.innerHTML = fs.readFileSync('./index.html');    
    const view = new CounterView();

    // 2. Act - click on the increment button
    const button = document.querySelector('#increment-button');
    button.click();

    // 3. Assert - using querySelector,
    // we get the DOM element and assert its content (should be '0')
    const counterEl = document.querySelector('#counter');
    expect(counterEl.innerText).toBe('1')
  });
});