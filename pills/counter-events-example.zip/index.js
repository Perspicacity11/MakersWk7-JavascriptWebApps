const CounterView = require("./counterView");

const counter = new CounterView();