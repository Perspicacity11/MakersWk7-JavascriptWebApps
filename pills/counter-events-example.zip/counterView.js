// file: counterView.js

class CounterView {

  // constructor() is executed when the instance is created,
  // so the value is immediately displayed as soon
  // as we call `new CounterView()`
  constructor() {
    document.querySelector('#counter').innerText = '0';
    document.querySelector('#increment-button').addEventListener('click', () => {
      const currentValue = document.querySelector('#counter').innerText;

      // .innerText returns a string, so we make sure it's converted
      // to a number before adding one, otherwise we'd get weird results!
      const newValue = parseInt(currentValue) + 1;

      document.querySelector('#counter').innerText = String(newValue);
    });
  }
}

module.exports = CounterView;