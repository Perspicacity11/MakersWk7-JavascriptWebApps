(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // counterView.js
  var require_counterView = __commonJS({
    "counterView.js"(exports, module) {
      var CounterView2 = class {
        constructor() {
          document.querySelector("#counter").innerText = "0";
          document.querySelector("#increment-button").addEventListener("click", () => {
            const currentValue = document.querySelector("#counter").innerText;
            const newValue = parseInt(currentValue) + 1;
            document.querySelector("#counter").innerText = newValue;
          });
        }
      };
      module.exports = CounterView2;
    }
  });

  // index.js
  var CounterView = require_counterView();
  var counter = new CounterView();
})();
